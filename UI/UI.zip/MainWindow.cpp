#include "MainWindow.h"

#include <QApplication>
#include <QToolBar>
#include <QPushButton>
#include <QFileDialog>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QLabel>
#include <QDragEnterEvent>
#include <QDropEvent>
#include <QMimeData>
#include <QStatusBar>
#include <QDir>
#include <QFontDatabase>
#include <QSizePolicy>
#include <filesystem>

namespace fs = std::filesystem;

static const QString APP_STYLE = R"(
QMainWindow, QWidget {
    background: #1e2230;
    color: #cdd6f4;
    font-family: "Segoe UI", "Helvetica Neue", Arial, sans-serif;
    font-size: 12px;
}
QDockWidget {
    border: none;
    titlebar-close-icon: url(none);
}
QDockWidget::title {
    background: #181825;
    color: #cba6f7;
    padding: 6px 10px;
    font-weight: bold;
}
QStatusBar {
    background: #181825;
    color: #6c7086;
    font-size: 11px;
}
QToolBar {
    background: #181825;
    border-bottom: 1px solid #313244;
    spacing: 8px;
    padding: 4px 8px;
}
QPushButton#openBtn {
    background: #cba6f7;
    color: #1e2230;
    border: none;
    padding: 6px 18px;
    border-radius: 5px;
    font-weight: bold;
}
QPushButton#openBtn:hover { background: #d0b4ff; }
QPushButton#openBtn:pressed { background: #b794f4; }
QLabel#pathLabel {
    color: #a6adc8;
    font-size: 11px;
    padding: 0 10px;
}
QScrollArea { border: none; }
QSplitter::handle { background: #313244; }
)";

// =============================================================================
//  Constructor
// =============================================================================
MainWindow::MainWindow(QWidget* parent)
    : QMainWindow(parent)
{
    setWindowTitle("Matrix One — Influence Line Viewer");
    setMinimumSize(1100, 700);
    resize(1280, 800);
    setAcceptDrops(true);
    setStyleSheet(APP_STYLE);

    buildToolbar();
    buildDock();
    buildStack();
    setStatus("Drop a project folder or click 'Open Project'");
}

// =============================================================================
//  buildToolbar
// =============================================================================
void MainWindow::buildToolbar()
{
    auto* bar = addToolBar("Main");
    bar->setMovable(false);
    bar->setFloatable(false);

    auto* openBtn = new QPushButton("📂  Open Project");
    openBtn->setObjectName("openBtn");
    connect(openBtn, &QPushButton::clicked, this, &MainWindow::onOpenProject);
    bar->addWidget(openBtn);

    pathLabel_ = new QLabel("No project loaded");
    pathLabel_->setObjectName("pathLabel");
    bar->addWidget(pathLabel_);

    // Spacer
    auto* spacer = new QWidget();
    spacer->setSizePolicy(QSizePolicy::Expanding, QSizePolicy::Preferred);
    bar->addWidget(spacer);

    // App badge
    auto* badge = new QLabel("Matrix One  v1.0");
    badge->setStyleSheet("color:#45475a; font-size:11px; padding-right:8px;");
    bar->addWidget(badge);
}

// =============================================================================
//  buildDock
// =============================================================================
void MainWindow::buildDock()
{
    browser_ = new ProjectBrowser();
    browser_->setMinimumWidth(220);
    browser_->setMaximumWidth(320);

    dockWidget_ = new QDockWidget("Project Browser", this);
    dockWidget_->setObjectName("projectDock");
    dockWidget_->setWidget(browser_);
    dockWidget_->setFeatures(QDockWidget::DockWidgetMovable);
    addDockWidget(Qt::LeftDockWidgetArea, dockWidget_);

    connect(browser_, &ProjectBrowser::curveSelected,
            this, &MainWindow::onCurveSelected);
    connect(browser_, &ProjectBrowser::criticalValuesRequested,
            this, &MainWindow::onCriticalValuesRequested);
    connect(browser_, &ProjectBrowser::envelopeRequested,
            this, &MainWindow::onEnvelopeRequested);
    connect(browser_, &ProjectBrowser::imageDirSelected,
            this, &MainWindow::onImageDirSelected);
    connect(browser_, &ProjectBrowser::modelInfoRequested,
            this, &MainWindow::onModelInfoRequested);
}

// =============================================================================
//  buildStack — Welcome page + all content panels
// =============================================================================
void MainWindow::buildStack()
{
    stack_ = new QStackedWidget();
    setCentralWidget(stack_);

    // ── 0 : Welcome ──────────────────────────────────────────────────────────
    welcome_ = new QWidget();
    welcome_->setStyleSheet("background:#1e2230;");
    auto* wl = new QVBoxLayout(welcome_);
    wl->setAlignment(Qt::AlignCenter);

    auto* icon = new QLabel("🏗");
    icon->setStyleSheet("font-size:64px;");
    icon->setAlignment(Qt::AlignCenter);

    auto* title = new QLabel("Matrix One — Influence Line Viewer");
    title->setStyleSheet(
        "font-size:22px; font-weight:bold; color:#cba6f7; margin-top:12px;");
    title->setAlignment(Qt::AlignCenter);

    auto* sub = new QLabel(
        "Open a project folder (the directory that contains path.json)\n"
        "or drag-and-drop it onto the window.");
    sub->setStyleSheet("font-size:13px; color:#6c7086; margin-top:8px;");
    sub->setAlignment(Qt::AlignCenter);

    auto* openBtn2 = new QPushButton("📂  Open Project");
    openBtn2->setObjectName("openBtn");
    openBtn2->setFixedWidth(200);
    connect(openBtn2, &QPushButton::clicked, this, &MainWindow::onOpenProject);

    wl->addStretch(1);
    wl->addWidget(icon);
    wl->addWidget(title);
    wl->addWidget(sub);
    wl->addSpacing(24);
    wl->addWidget(openBtn2, 0, Qt::AlignCenter);
    wl->addStretch(2);

    stack_->addWidget(welcome_);    // index 0

    // ── 1 : Influence Line Viewer ─────────────────────────────────────────────
    ilViewer_ = new InfluenceLineViewer();
    stack_->addWidget(ilViewer_);   // index 1

    // ── 2 : Critical Values ───────────────────────────────────────────────────
    critPanel_ = new CriticalValuesPanel();
    stack_->addWidget(critPanel_);  // index 2

    // ── 3 : Load Envelopes ────────────────────────────────────────────────────
    envPanel_ = new LoadEnvelopePanel();
    stack_->addWidget(envPanel_);   // index 3

    // ── 4 : Image Gallery ─────────────────────────────────────────────────────
    gallery_ = new ImageGallery();
    stack_->addWidget(gallery_);    // index 4

    // ── 5 : Model Info ────────────────────────────────────────────────────────
    modelPanel_ = new ModelInfoPanel();
    stack_->addWidget(modelPanel_); // index 5

    stack_->setCurrentIndex(0);
}

// =============================================================================
//  onOpenProject
// =============================================================================
void MainWindow::onOpenProject()
{
    const QString dir = QFileDialog::getExistingDirectory(
        this,
        "Open Matrix One Project",
        QDir::homePath(),
        QFileDialog::ShowDirsOnly | QFileDialog::DontResolveSymlinks);

    if (!dir.isEmpty())
        loadProject(dir);
}

// =============================================================================
//  loadProject
// =============================================================================
void MainWindow::loadProject(const QString& dir)
{
    jutils::Paths p(fs::path(dir.toStdString()));

    if (!p.valid()) {
        setStatus(QString("Invalid project: %1").arg(dir), true);
        return;
    }

    paths_ = p;

    // Also try to resolve configPath from path.json if one exists
    const auto resolved = jutils::detect_root(p.root);
    if (!resolved.empty() && fs::exists(resolved))
        paths_ = jutils::Paths(resolved);

    browser_->setRoot(paths_);
    ilViewer_->setPaths(paths_);
    critPanel_->setPaths(paths_);
    envPanel_->setPaths(paths_);
    modelPanel_->setPaths(paths_);

    pathLabel_->setText(QString::fromStdString(paths_.root.string()));
    setStatus(QString("Project loaded: %1")
              .arg(QString::fromStdString(paths_.root.filename().string())));
    stack_->setCurrentIndex(0); // Show welcome until user picks something
}

// =============================================================================
//  Slots from ProjectBrowser
// =============================================================================
void MainWindow::onCurveSelected(const QString& /*name*/, const QString& file)
{
    ilViewer_->showCurve(file);
    stack_->setCurrentIndex(1);
}

void MainWindow::onCriticalValuesRequested()
{
    stack_->setCurrentIndex(2);
}

void MainWindow::onEnvelopeRequested(const QString& scope, const QString& loadType)
{
    envPanel_->showEnvelope(scope, loadType);
    stack_->setCurrentIndex(3);
}

void MainWindow::onImageDirSelected(const QString& dirPath)
{
    gallery_->setDirectory(dirPath);
    stack_->setCurrentIndex(4);
}

void MainWindow::onModelInfoRequested()
{
    stack_->setCurrentIndex(5);
}

// =============================================================================
//  Drag & Drop support — drop a project folder directly onto the window
// =============================================================================
void MainWindow::dragEnterEvent(QDragEnterEvent* e)
{
    if (e->mimeData()->hasUrls())
        e->acceptProposedAction();
}

void MainWindow::dropEvent(QDropEvent* e)
{
    const auto& urls = e->mimeData()->urls();
    if (!urls.isEmpty()) {
        const QString path = urls.first().toLocalFile();
        if (QDir(path).exists())
            loadProject(path);
    }
}

// =============================================================================
//  Status bar
// =============================================================================
void MainWindow::setStatus(const QString& msg, bool error)
{
    statusBar()->setStyleSheet(
        error ? "background:#181825; color:#f38ba8;"
              : "background:#181825; color:#6c7086;");
    statusBar()->showMessage(msg);
}
