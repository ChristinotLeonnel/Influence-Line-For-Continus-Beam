#include "MainWindow.h"

#include <QApplication>
#include <QDir>
#include <QPalette>
#include <QStyle>
#include <QStyleFactory>
#include <QTimer>

// =============================================================================
//  Dark system palette (fallback when OS theme is light)
// =============================================================================
static QPalette darkPalette()
{
    QPalette p;
    p.setColor(QPalette::Window,          QColor("#1e2230"));
    p.setColor(QPalette::WindowText,      QColor("#cdd6f4"));
    p.setColor(QPalette::Base,            QColor("#181825"));
    p.setColor(QPalette::AlternateBase,   QColor("#2a2d3e"));
    p.setColor(QPalette::Text,            QColor("#cdd6f4"));
    p.setColor(QPalette::Button,          QColor("#313244"));
    p.setColor(QPalette::ButtonText,      QColor("#cdd6f4"));
    p.setColor(QPalette::Highlight,       QColor("#cba6f7"));
    p.setColor(QPalette::HighlightedText, QColor("#1e2230"));
    p.setColor(QPalette::Link,            QColor("#89b4fa"));
    p.setColor(QPalette::ToolTipBase,     QColor("#313244"));
    p.setColor(QPalette::ToolTipText,     QColor("#cdd6f4"));
    p.setColor(QPalette::Disabled, QPalette::Text,       QColor("#6c7086"));
    p.setColor(QPalette::Disabled, QPalette::ButtonText, QColor("#6c7086"));
    return p;
}

// =============================================================================
//  main
// =============================================================================
int main(int argc, char* argv[])
{
#if QT_VERSION < QT_VERSION_CHECK(6, 0, 0)
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    QApplication::setAttribute(Qt::AA_UseHighDpiPixmaps);
#endif

    QApplication app(argc, argv);
    app.setApplicationName("Matrix One Viewer");
    app.setApplicationVersion("1.0");
    app.setOrganizationName("MatrixOne");

    // Use the Fusion style which supports custom palettes on all platforms
    app.setStyle(QStyleFactory::create("Fusion"));
    app.setPalette(darkPalette());

    MainWindow win;
    win.show();

    // If a path was passed as the first argument, open it automatically
    if (argc > 1) {
        const QString arg = QString::fromLocal8Bit(argv[1]);
        if (QDir(arg).exists())
            win.setProperty("autoLoadPath", arg);
            // Actually invoke loadProject via QTimer so the window is shown first:
        QTimer::singleShot(0, &win, [&win, arg]() {
            QMetaObject::invokeMethod(&win, "loadProject",
                Qt::QueuedConnection,
                Q_ARG(QString, arg));
        });
    }

    return app.exec();
}
